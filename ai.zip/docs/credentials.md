`https://comparebestbrokers.com/`
`https://comparebestbrokers.com/cbb_wp/wp-admin`
`https://comparebestbrokers.com/cbb_wp/wp-json/wp/v2/brokers`
`https://comparebestbrokers.com/cbb_wp/wp-json/wp-menus/v1/menus/navMenu`
`https://comparebestbrokers.com/cbb_wp/wp-json/wp/v2/posts?_embed`
`https://comparebestbrokers.com/cbb_wp/wp-json/acf/v2/options`
`https://comparebestbrokers.com/sitemap.xml`

`git push brokers master`







## Thank you email:
- Server: smtp.titan.email
- Port 465 + SSL 
- info@comparebestbrokers.com
- 6Letters$$







## Hostinger:

- user : yannick.edmond@gmail.com
- pass : Curepipe25$$

## WP-admin

- user: Veljko
- pass: VeljRad847
